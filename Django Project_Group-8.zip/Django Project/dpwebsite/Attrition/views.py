from django.shortcuts import render
from .models import Ibm

# Create your views here.
def attr(request):
    att= Ibm.objects.all()
    
    for i in att:
        return i.Department,i.HourlyRate