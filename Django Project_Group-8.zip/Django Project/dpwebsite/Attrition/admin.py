from django.contrib import admin
from .models import Ibm
# Register your models here.

admin.site.urls(Ibm)