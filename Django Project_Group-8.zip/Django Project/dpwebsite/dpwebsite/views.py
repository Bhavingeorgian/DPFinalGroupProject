from django.http import HttpResponse
from django.shortcuts import render

def homePage(request):
    data = "Current Data"

    context = {
        "data":data
    }
    return render(request,"index.html",context)